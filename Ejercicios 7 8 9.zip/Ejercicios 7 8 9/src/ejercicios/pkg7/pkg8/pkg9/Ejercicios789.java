package ejercicios.pkg7.pkg8.pkg9;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Vector;

public class Ejercicios789 {

    /*Dada la función: public static String reverse(String texto) { }

Escribe el código que devuelva una cadena al revés. Por ejemplo, la cadena "hola mundo", debe retornar "odnum aloh".

Crea un array unidimensional de Strings y recórrelo, mostrando únicamente sus valores.

Crea un array bidimensional de enteros y recórrelo, mostrando la posición y el valor de cada elemento en ambas dimensiones.

Crea un "Vector" del tipo de dato que prefieras, y añádele 5 elementos. Elimina el 2o y 3er elemento y muestra el resultado final.

Indica cuál es el problema de utilizar un Vector con la capacidad por defecto si tuviésemos 1000 elementos para ser añadidos al mismo.

Crea un ArrayList de tipo String, con 4 elementos. Cópialo en una LinkedList. Recorre ambos mostrando únicamente el valor de cada elemento.

Crea un ArrayList de tipo int, y, utilizando un bucle rellénalo con elementos 1..10. A continuación, con otro bucle, recórrelo y elimina los numeros pares. 
Por último, vuelve a recorrerlo y muestra el ArrayList final. 
Si te atreves, puedes hacerlo en menos pasos, siempre y cuando cumplas el primer "for" de relleno.

Crea una función DividePorCero. Esta, debe generar una excepción ("throws") a su llamante del tipo ArithmeticException 
    que será capturada por su llamante (desde "main", por ejemplo). 
   Si se dispara la excepción, mostraremos el mensaje "Esto no puede hacerse". Finalmente, mostraremos en cualquier caso: "Demo de código".

Utilizando InputStream y PrintStream, crea una función que reciba dos parámetros: "fileIn" y "fileOut". 
    La tarea de la función será realizar la copia del fichero dado en el parámetro "fileIn" al fichero dado en "fileOut".

Sorpréndenos creando un programa de tu elección que utilice InputStream, PrintStream, excepciones, un HashMap y un ArrayList, LinkedList o array.*/
    public static void main(String[] args) {

        String cadena = "Mensaje de texto";

        for (int i = 0; i < cadena.length(); i++) {
            System.out.print("" + cadena.charAt(i));
        }

        System.out.println("");

        for (int i = cadena.length() - 1; i >= 0; i--) {
            System.out.print("" + cadena.charAt(i));
        }

        System.out.println("");
        System.out.println("");

        String[] arreglo = {
            "Pizza",
            "Tortas",
            "Tacos"
        };

        for (String nombre : arreglo) {
            System.out.println("" + nombre);
        }

        System.out.println("");
        System.out.println("");

        int[][] numero = new int[2][3];
        numero[0][0] = 1;
        numero[0][1] = 2;
        numero[0][2] = 3;

        numero[1][0] = 10;
        numero[1][1] = 20;
        numero[1][2] = 30;

        for (int i = 0; i < numero.length; i++) {
            System.out.println("Valor de i = " + i);

            for (int j = 0; j < numero.length; j++) {
                System.out.println("Valor de j = " + j);
                System.out.println(numero[i][j]);
            }
        }

        System.out.println("");
        System.out.println("");

        Vector vector = new Vector();
        vector.addElement("uno");
        vector.addElement("dos");
        vector.addElement("tres");
        vector.addElement("cuatro");
        vector.addElement("cinco");

        vector.removeElement("dos");
        vector.removeElement("tres");

        System.out.println("El vector ahora tiene los elementos " + vector);

        //El problema es que su capacidad puede aumentar mucho, lo cual hace que crezca automaticamente. Y puede generar una operación muy costosa a la larga
        System.out.println("");
        System.out.println("");

        System.out.println("ArrayList");
        ArrayList<String> valores = new ArrayList<>();
        valores.add("Java");
        valores.add("PHP");
        valores.add("MySQL");
        valores.add("JS");

        for (String programas : valores) {
            System.out.println("" + programas);
        }

        System.out.println("");
        System.out.println("LinkedList");
        LinkedList<String> listaEnlazada = new LinkedList<>(valores);

        for (String programas : listaEnlazada) {
            System.out.println("" + programas);
        }

        System.out.println("");
        System.out.println("");

        ArrayList<Integer> lista = new ArrayList<>();
        
        for (int i = 1; i <= 10; i++) {
            lista.add(i);
        }

        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i) % 2 == 0) {
                lista.remove(i);
            }
        }

        for (Integer numeros : lista) {
            System.out.println("Numero: " + numeros);
        }
        
        System.out.println("");
        System.out.println("");
        
       int a = 4;
       int b =0;
       divide(a, b);
    }
    
    public static int divide(int a, int b) throws ArithmeticException{
        int resultado = 0;
        try {
              resultado = a / b;
              System.out.println("El resultado es " + resultado);
              System.out.println("Demo de código");
        } catch (ArithmeticException  e) {
             System.out.println("Esto no puede hacerse" + e.getMessage());
             System.out.println("Demo de código");
        }
        return resultado;
    }
    
    public static void copiarArchivo (String fileIn, String fileOut) {
    try {
        InputStream entrada = new FileInputStream(fileIn);

        byte[] datos  = entrada.readAllBytes();
        
        PrintStream salida = new PrintStream("destino.txt");
        salida.write(datos);
        } catch(Exception e){
                System.out.println(e.getMessage());
        }
}
}
